# ESP8266 AT FIRMWARE


For detailed instructions about flashing the WiFi firmware see README.md in **flash** directory.

